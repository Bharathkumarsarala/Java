package exam;

import java.util.Scanner;

public class Fifth {
	
	
	
}


