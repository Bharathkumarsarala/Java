package exam;

public class Second {

}
