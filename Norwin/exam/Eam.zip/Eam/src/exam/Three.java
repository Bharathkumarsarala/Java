package exam;

public class Three {
	
		
		public int factor(int i) {
			if(i==0) {
				return 1;
				return * factor(i-1);
			}
			}
		public static void main(String args[]) {

}
